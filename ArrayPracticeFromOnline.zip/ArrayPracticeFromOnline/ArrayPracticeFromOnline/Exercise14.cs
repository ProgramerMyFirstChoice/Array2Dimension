﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPracticeFromOnline
{
    /*
     Write a program in C# Sharp for A 2D array of size 3x3 and print the matrix
         
         */
    class Exercise14
    {
        static void Main(string[] args)
        {
           
            int[,] arr1 = new int[3, 3];

            Console.Write("\n\nRead a 2D array of size 3X3 and print the martix  :\n");
            Console.Write("------------------------------------------------------\n");
            start:
            /* Stored values into the array*/
            Console.Write("Enter elements in the matrix :\n");
           
            int i, j;
            try
            {
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 3; j++)
                    {
                        Console.Write("Element - [{0},{1}] : ", i, j);
                        arr1[i, j] = Convert.ToInt32(Console.ReadLine());

                    }
                }

            }
            catch (Exception)
            {

                Console.Write("Please Enter interger number\n");
               goto start;
            }
            
            Console.Write("\nThe matrix is : \n");

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write("{0}\t", i, j);                  
                }

                Console.Write("\n\n");
            }

            Console.ReadKey();

        }
    }
}
