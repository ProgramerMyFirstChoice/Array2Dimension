﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            const int SIZE = 5;
            int[] firstArray = {5, 10, 15, 20, 25 };
            int[] secondArray = new int[SIZE];

            // Copy the source to the target.
            //
            Array.Copy(firstArray, secondArray, 5);

            //for (int i = 0; i < firstArray.Length; i++)
            //{
            //    secondArray[i] = firstArray[i];
            //}

            foreach (int array in secondArray)
            {
                Console.Write(array + ", ");
            }

            Console.ReadLine();
        }
    }
}
