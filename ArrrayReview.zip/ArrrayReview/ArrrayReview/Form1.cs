﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArrrayReview
{
    public partial class Form1 : Form
    {
        /*
          Nahom Gebreyohannies
         
          CSI 154
          January 12, 2018
          Code for Array Review Assignment 
        */
        public Form1()
        {
            InitializeComponent();
        }

        // Creating an array for random value
        int[] randomValueArray = new int[10];


        private void btnDisplay_Click(object sender, EventArgs e)
        {
            // Clear the richbox
            richDisplayArray.Clear();

            // Initialize the Array with random number 
            // starting with min -10 and 100
            InitializeArray(randomValueArray, -10, 100);

            // Find the number of negative number in the array
            // And assign it to int negativeCount variable 
            int negativeCount = GetNumOfNegatives(randomValueArray);

            // Calculte the Average value of even postive element of the array
            double averageEvenPostive = GetAvgOfEvenPostive(randomValueArray);

            // Get the first odd negative number and assign it to variable
            int firstOddNegative = GetFirstOddNegative(randomValueArray);

            // Calculate the average of negative elements of the array
            double averageNegative = GetAvgOfNegatives(randomValueArray);

            // Display the calculated value and the count in the label text control
            lblNumberOfNegative.Text = negativeCount.ToString();
            lblAverageEvenPostive.Text = averageEvenPostive.ToString("n");
            lblAverageOfNegative.Text = averageNegative.ToString("n");
            lblFirstOddNegative.Text = firstOddNegative.ToString();

            // Displat the array, sorted array , and reversed array
            // in richbox text control
            richDisplayArray.AppendText("\n\tThe value of an array Created by random number\n");
            DisplayArray(randomValueArray);
            SortArray(randomValueArray);
            ReverseArray(randomValueArray);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear the 
            richDisplayArray.Clear();
            lblAverageOfNegative.Text = "";
            lblNumberOfNegative.Text = "";
            lblAverageEvenPostive.Text = "";
            lblFirstOddNegative.Text = "";
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            // Clear the richbox
            richDisplayArray.Clear();

            // Sort the Array
            SortArray(randomValueArray);
        }

        // Method that sort the array parameter
        private void SortArray(int[] iArray)
        {
            // Sort array
            Array.Sort(iArray);

            // Display the sorted array
            richDisplayArray.AppendText("\n\tThe Sorted value of an array\n");
            DisplayArray(iArray);
        }

        private void btnReverse_Click(object sender, EventArgs e)
        {
            // Clear the richbox
            richDisplayArray.Clear();

            // Reverse the array
            ReverseArray(randomValueArray);
        }

        // Method that reverse the array parameter
        private void ReverseArray(int[] iArray)
        {
            // Reverse the array
            Array.Reverse(iArray);

            // Display the reversed array
            richDisplayArray.AppendText("\n\tThe Reversed value of the array\n");
            DisplayArray(iArray);
        }

        #region InitializeArray(),GetNumOfNegatives(), GetAvgOfNegatives, GetAvgOfEvenPostive,GetFirstOddNegative(),DisplayArray.

        // Create a random object
        Random rand = new Random();

        // Define a method that takes an array and initializes it 
        // with random values ranging from min to max
        private void InitializeArray(int[] array, int min, int max)
        {
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = rand.Next(min, max);
            }
        }

        // A method that returns the number of negative values
        // in an array
        private int GetNumOfNegatives(int[] array)
        {
            int nCount = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] < 0)
                {
                    nCount++;
                }
            }

            return nCount;
        }

        // Method that returns the average of all 
        // the negative value in the array
        private double GetAvgOfNegatives(int[] array)
        {
            int nCount = 0;
            double nSum = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] < 0)
                {
                    nSum += array[i];
                    nCount++;
                }
            }

            return nSum / nCount;
        }

        // Method that returns the average of all 
        // the postive even value in the array
        private double GetAvgOfEvenPostive(int[] array)
        {
            int postiveCount = 0;
            double postiveSum = 0;
            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] > 0 && array[i] % 2 == 0)
                {
                    postiveSum += array[i];
                    postiveCount++;
                }
            }

            return postiveSum / postiveCount;
        }

        // Method that returns the average of all 
        // the negative odd value in the array
        private int GetFirstOddNegative(int[] array)
        {

            for (int i = 0; i < array.Length; i++)
            {
                if (array[i] < 0 && array[i] % 2 != 0)
                {
                    return array[i];
                }
            }
            // Return 0 if there isn't an odd negative number
            return 0;
        }

        // Method that display an array
        private void DisplayArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                richDisplayArray.AppendText("\t" + array[i].ToString() + "  ");
            }
        }
        #endregion
    }
}
