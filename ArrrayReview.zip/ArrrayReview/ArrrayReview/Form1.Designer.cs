﻿namespace ArrrayReview
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richDisplayArray = new System.Windows.Forms.RichTextBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.lblNumberOfNegative = new System.Windows.Forms.Label();
            this.lblAverageOfNegative = new System.Windows.Forms.Label();
            this.lblFirstOddNegative = new System.Windows.Forms.Label();
            this.lblAverageEvenPostive = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnSort = new System.Windows.Forms.Button();
            this.btnReverse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richDisplayArray
            // 
            this.richDisplayArray.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.richDisplayArray.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richDisplayArray.Location = new System.Drawing.Point(21, 12);
            this.richDisplayArray.Name = "richDisplayArray";
            this.richDisplayArray.ReadOnly = true;
            this.richDisplayArray.Size = new System.Drawing.Size(615, 166);
            this.richDisplayArray.TabIndex = 0;
            this.richDisplayArray.Text = "";
            // 
            // btnDisplay
            // 
            this.btnDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplay.Location = new System.Drawing.Point(12, 369);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(107, 38);
            this.btnDisplay.TabIndex = 1;
            this.btnDisplay.Text = "Display ";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // lblNumberOfNegative
            // 
            this.lblNumberOfNegative.BackColor = System.Drawing.Color.White;
            this.lblNumberOfNegative.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumberOfNegative.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumberOfNegative.Location = new System.Drawing.Point(536, 187);
            this.lblNumberOfNegative.Name = "lblNumberOfNegative";
            this.lblNumberOfNegative.Size = new System.Drawing.Size(100, 31);
            this.lblNumberOfNegative.TabIndex = 2;
            this.lblNumberOfNegative.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAverageOfNegative
            // 
            this.lblAverageOfNegative.BackColor = System.Drawing.Color.White;
            this.lblAverageOfNegative.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAverageOfNegative.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAverageOfNegative.Location = new System.Drawing.Point(536, 227);
            this.lblAverageOfNegative.Name = "lblAverageOfNegative";
            this.lblAverageOfNegative.Size = new System.Drawing.Size(100, 31);
            this.lblAverageOfNegative.TabIndex = 2;
            this.lblAverageOfNegative.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblFirstOddNegative
            // 
            this.lblFirstOddNegative.BackColor = System.Drawing.Color.White;
            this.lblFirstOddNegative.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFirstOddNegative.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstOddNegative.Location = new System.Drawing.Point(536, 317);
            this.lblFirstOddNegative.Name = "lblFirstOddNegative";
            this.lblFirstOddNegative.Size = new System.Drawing.Size(100, 31);
            this.lblFirstOddNegative.TabIndex = 2;
            this.lblFirstOddNegative.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAverageEvenPostive
            // 
            this.lblAverageEvenPostive.BackColor = System.Drawing.Color.White;
            this.lblAverageEvenPostive.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAverageEvenPostive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAverageEvenPostive.Location = new System.Drawing.Point(536, 270);
            this.lblAverageEvenPostive.Name = "lblAverageEvenPostive";
            this.lblAverageEvenPostive.Size = new System.Drawing.Size(100, 31);
            this.lblAverageEvenPostive.TabIndex = 2;
            this.lblAverageEvenPostive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(126, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(311, 20);
            this.label5.TabIndex = 3;
            this.label5.Text = "Number of Negative value in the Array";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(126, 238);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(346, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Average of the negative value of the Array";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(126, 281);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(379, 20);
            this.label7.TabIndex = 4;
            this.label7.Text = "Average of the Even Postive value of the array";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(126, 328);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(327, 20);
            this.label8.TabIndex = 4;
            this.label8.Text = "The first odd negative value of the array";
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(142, 370);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(107, 38);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(529, 368);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(107, 38);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnSort
            // 
            this.btnSort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSort.Location = new System.Drawing.Point(270, 370);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(107, 38);
            this.btnSort.TabIndex = 7;
            this.btnSort.Text = "Sort";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // btnReverse
            // 
            this.btnReverse.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReverse.Location = new System.Drawing.Point(398, 368);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(107, 38);
            this.btnReverse.TabIndex = 8;
            this.btnReverse.Text = "Reverse";
            this.btnReverse.UseVisualStyleBackColor = true;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(661, 418);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.btnSort);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblAverageEvenPostive);
            this.Controls.Add(this.lblFirstOddNegative);
            this.Controls.Add(this.lblAverageOfNegative);
            this.Controls.Add(this.lblNumberOfNegative);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.richDisplayArray);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richDisplayArray;
        private System.Windows.Forms.Button btnDisplay;
        private System.Windows.Forms.Label lblNumberOfNegative;
        private System.Windows.Forms.Label lblAverageOfNegative;
        private System.Windows.Forms.Label lblFirstOddNegative;
        private System.Windows.Forms.Label lblAverageEvenPostive;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.Button btnReverse;
    }
}

