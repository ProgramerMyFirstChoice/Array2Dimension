﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayPractice
{
    /*  Nahom Gebreyohannies
      
          Assignment for CSI 152
          Christy Hernadez
     */
    class ArrayPractice
    {
        // The Main method 
        static void Main(string[] args)
        {
            try
            {
                // Create an array to hold number input by user
                const int SIZE = 10;
                int[] numbers = new int[SIZE];

                // Local variable
                string inputString;   // String for the user input
                int sum = 0;         // The sum number
                double average;      // The average number
                int highsetNumber;  // The highestnumber variable
                int lowest;         // The lowest number variable

                // Background color for Console
                Console.BackgroundColor = ConsoleColor.Cyan;
                Console.Clear();

                // read the number into array. 
                // Find the sum of the number enter by user
                int sub = 0;
                while (sub < SIZE)
                {
                    Console.Write("Enter integer number for number {0} is  ", sub + 1);
                    inputString = Console.ReadLine();
                    numbers[sub] = Convert.ToInt32(inputString);
                    sum = sum + numbers[sub];
                    sub++;
                }

                // Find the Avearge number of the array
                average = (double)sum / SIZE;

                // Get the highest and lowest number.
                highsetNumber = Highest(numbers);
                lowest = Lowest(numbers);

                // Display into console average, sum, highest, lowest , sorted, and reversed value of the array

                Console.ForegroundColor = ConsoleColor.Red; // Change the color of the letter

                Console.WriteLine("\n---------------------------------------------------------------");
                Console.WriteLine("Sum\tAvearge\t  HighsetNumber\t\t LowestNumber\t");
                Console.WriteLine("---------------------------------------------------------------");
                Console.WriteLine("{0,1 }{1,10 }{2,18 }{3,20 }", sum, average, highsetNumber, lowest);

                Console.WriteLine("---------------------------------------------------------------");
                Console.WriteLine("Numbers in original order:");
                sub = DisplayArrayValue(numbers); // List the value of the array elements

                // Display sorted number
                Console.WriteLine("\n---------------------------------------------------------------");
                Array.Sort(numbers); // sort the array
                Console.WriteLine("Numbers in sorted order:");
                sub = DisplayArrayValue(numbers);// List the value of the array elements

                Console.WriteLine("\n---------------------------------------------------------------");
                Array.Reverse(numbers);// reverse the array
                Console.WriteLine("Numbers in reverse order:");
                sub = DisplayArrayValue(numbers);// List the value of the array elements

                Console.WriteLine("\n---------------------Thank You-------------------------------");

            }
            catch (Exception ex) // print error message
            {

                Console.WriteLine("\nPlease Enter 10 integer number for the Array");

                Console.WriteLine(ex.StackTrace); // It will tell which line in the 
                                                  //programe that create error
            }
            Console.ReadLine();
        }

        // The Display Array method accept an array argument
        // and return the postion number
        private static int DisplayArrayValue(int[] iArrays)
        {
            // Declare constant integer for the size of array
            const int SIZE = 10;

            //step through the array and display it value
            int sub = 0;
            while (sub < SIZE)
            {
                Console.Write("{0, 6}", iArrays[sub]);
                sub++;
            }

            return sub;
        }

        //The Highset method accepts an int array argument
        //and return the highest value in the array
        private static int Highest(int[] iArray)
        {
            // Declare a variable for highest value and intialize it with
            //the first value of the array
            int highest = iArray[0];

            // step through the rest of the array, beginning at element 1. when avalue
            //greater than highest is found
            //assign that value to the highest
            for (int sub = 0; sub < iArray.Length; sub++)
            {
                if (iArray[sub] > highest)
                {
                    highest = iArray[sub];
                }
            }
            return highest; // return the highest value
        }

        //The Lowest method accepts an int array argument
        //and return the lowest value in the array
        private static int Lowest(int[] iArray)
        {
            // Declare a variable for lowest value and intialize with
            //the first value of the array
            int lowest = iArray[0];

            // step through the rest of the array, beginning at element 1. when avalue
            //less than lowest is found
            //assign that value to the lowest
            for (int sub = 0; sub < iArray.Length; sub++)
            {
                if (iArray[sub] < lowest)
                {
                    lowest = iArray[sub];
                }
            }
            return lowest;// return the lowest
        }
    }
}
